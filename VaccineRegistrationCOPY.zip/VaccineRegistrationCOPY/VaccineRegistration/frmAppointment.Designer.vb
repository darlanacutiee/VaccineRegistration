﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAppointment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAppointment))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.cboDose = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtRegisno = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.cboVaccine = New System.Windows.Forms.ComboBox()
        Me.cboVenue = New System.Windows.Forms.ComboBox()
        Me.cboTimeSlot = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.dtpDate = New System.Windows.Forms.DateTimePicker()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnBook = New System.Windows.Forms.Button()
        Me.lblTime = New System.Windows.Forms.Label()
        Me.tmrAppointment = New System.Windows.Forms.Timer(Me.components)
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.GhostWhite
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.PictureBox4)
        Me.GroupBox1.Controls.Add(Me.cboDose)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtRegisno)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.cboVaccine)
        Me.GroupBox1.Controls.Add(Me.cboVenue)
        Me.GroupBox1.Controls.Add(Me.cboTimeSlot)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.dtpDate)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Tai Le", 15.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.Crimson
        Me.GroupBox1.Location = New System.Drawing.Point(24, 30)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(599, 423)
        Me.GroupBox1.TabIndex = 17
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Schedule an appointment"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label2.Location = New System.Drawing.Point(185, 53)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(178, 14)
        Me.Label2.TabIndex = 136
        Me.Label2.Text = "Please enter your registration no."
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.SystemColors.ControlLight
        Me.PictureBox4.Image = Global.VaccineRegistration.My.Resources.Resources.G8
        Me.PictureBox4.Location = New System.Drawing.Point(492, 32)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(87, 74)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 135
        Me.PictureBox4.TabStop = False
        '
        'cboDose
        '
        Me.cboDose.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDose.Font = New System.Drawing.Font("Microsoft Tai Le", 11.0!)
        Me.cboDose.FormattingEnabled = True
        Me.cboDose.Items.AddRange(New Object() {"First Dose", "Second Dose"})
        Me.cboDose.Location = New System.Drawing.Point(188, 124)
        Me.cboDose.Name = "cboDose"
        Me.cboDose.Size = New System.Drawing.Size(204, 27)
        Me.cboDose.TabIndex = 31
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label1.Location = New System.Drawing.Point(124, 128)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(44, 16)
        Me.Label1.TabIndex = 30
        Me.Label1.Text = "Dose"
        '
        'txtRegisno
        '
        Me.txtRegisno.Font = New System.Drawing.Font("Microsoft Tai Le", 11.0!)
        Me.txtRegisno.Location = New System.Drawing.Point(188, 70)
        Me.txtRegisno.Name = "txtRegisno"
        Me.txtRegisno.Size = New System.Drawing.Size(105, 26)
        Me.txtRegisno.TabIndex = 25
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.Color.Transparent
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label11.Location = New System.Drawing.Point(49, 74)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(119, 16)
        Me.Label11.TabIndex = 26
        Me.Label11.Text = "Registration No."
        '
        'cboVaccine
        '
        Me.cboVaccine.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboVaccine.Font = New System.Drawing.Font("Microsoft Tai Le", 11.0!)
        Me.cboVaccine.FormattingEnabled = True
        Me.cboVaccine.Items.AddRange(New Object() {"Pfizer", "AstraZeneca", "Sinovac", "Sputnik V", "Johnson and Johnsons", "Moderna"})
        Me.cboVaccine.Location = New System.Drawing.Point(188, 179)
        Me.cboVaccine.Name = "cboVaccine"
        Me.cboVaccine.Size = New System.Drawing.Size(204, 27)
        Me.cboVaccine.TabIndex = 23
        '
        'cboVenue
        '
        Me.cboVenue.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboVenue.Font = New System.Drawing.Font("Microsoft Tai Le", 11.0!)
        Me.cboVenue.FormattingEnabled = True
        Me.cboVenue.Items.AddRange(New Object() {"City Hall Quadrangle", "East Rembo Elementary School", "Makati High School"})
        Me.cboVenue.Location = New System.Drawing.Point(188, 288)
        Me.cboVenue.Name = "cboVenue"
        Me.cboVenue.Size = New System.Drawing.Size(242, 27)
        Me.cboVenue.TabIndex = 22
        '
        'cboTimeSlot
        '
        Me.cboTimeSlot.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTimeSlot.Font = New System.Drawing.Font("Microsoft Tai Le", 11.0!)
        Me.cboTimeSlot.FormattingEnabled = True
        Me.cboTimeSlot.Items.AddRange(New Object() {"Morning (7:00AM - 9:00AM)", "Afternoon (1:00PM - 3:00PM)"})
        Me.cboTimeSlot.Location = New System.Drawing.Point(188, 343)
        Me.cboTimeSlot.Name = "cboTimeSlot"
        Me.cboTimeSlot.Size = New System.Drawing.Size(242, 27)
        Me.cboTimeSlot.TabIndex = 16
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label7.Location = New System.Drawing.Point(95, 344)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(73, 16)
        Me.Label7.TabIndex = 12
        Me.Label7.Text = "Time Slot"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label6.Location = New System.Drawing.Point(45, 290)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(123, 16)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Venue / Location"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label5.Location = New System.Drawing.Point(16, 182)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(152, 16)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "Choose your vaccine"
        '
        'dtpDate
        '
        Me.dtpDate.Font = New System.Drawing.Font("Microsoft Tai Le", 11.0!)
        Me.dtpDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom
        Me.dtpDate.Location = New System.Drawing.Point(188, 234)
        Me.dtpDate.MaxDate = New Date(2023, 12, 31, 0, 0, 0, 0)
        Me.dtpDate.MinDate = New Date(2022, 5, 14, 0, 0, 0, 0)
        Me.dtpDate.Name = "dtpDate"
        Me.dtpDate.Size = New System.Drawing.Size(204, 26)
        Me.dtpDate.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label4.Location = New System.Drawing.Point(38, 236)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(130, 16)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Appointment Date"
        '
        'btnBook
        '
        Me.btnBook.BackColor = System.Drawing.Color.DarkGoldenrod
        Me.btnBook.FlatAppearance.BorderColor = System.Drawing.Color.Black
        Me.btnBook.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBook.Font = New System.Drawing.Font("Microsoft Tai Le", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBook.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnBook.Image = Global.VaccineRegistration.My.Resources.Resources.BTNBG
        Me.btnBook.Location = New System.Drawing.Point(467, 467)
        Me.btnBook.Name = "btnBook"
        Me.btnBook.Size = New System.Drawing.Size(146, 44)
        Me.btnBook.TabIndex = 24
        Me.btnBook.Text = "Book Now"
        Me.btnBook.UseVisualStyleBackColor = False
        '
        'lblTime
        '
        Me.lblTime.AutoSize = True
        Me.lblTime.BackColor = System.Drawing.Color.Transparent
        Me.lblTime.Font = New System.Drawing.Font("Microsoft Tai Le", 10.0!)
        Me.lblTime.Location = New System.Drawing.Point(291, 9)
        Me.lblTime.Name = "lblTime"
        Me.lblTime.Size = New System.Drawing.Size(20, 18)
        Me.lblTime.TabIndex = 32
        Me.lblTime.Text = "--"
        '
        'tmrAppointment
        '
        '
        'frmAppointment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.GhostWhite
        Me.ClientSize = New System.Drawing.Size(635, 523)
        Me.ControlBox = False
        Me.Controls.Add(Me.lblTime)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnBook)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmAppointment"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents cboVaccine As ComboBox
    Friend WithEvents cboVenue As ComboBox
    Friend WithEvents cboTimeSlot As ComboBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents dtpDate As DateTimePicker
    Friend WithEvents Label4 As Label
    Friend WithEvents btnBook As Button
    Friend WithEvents txtRegisno As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents cboDose As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents lblTime As Label
    Friend WithEvents tmrAppointment As Timer
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents Label2 As Label
End Class
