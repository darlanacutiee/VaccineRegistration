﻿Imports System.Data
Imports System.Data.SqlClient

Public Class frmRegister

    Dim checkUsername, priolevel, gender, pass As String
    Dim accountId As Integer

    Private Sub tmrRegis_Tick(ByVal sender As Object, e As EventArgs) Handles tmrRegis.Tick

        pass = txtPassword.Text

        lblTime.Text = DateTime.Now
        dtpBirthdate.MaxDate = DateTime.Today

        If (txtFname.Text <> "" And txtLname.Text <> "" And txtContactNo.Text <> "" And
            txtAddress.Text <> "" And dtpBirthdate.Value <> DateTime.Today And txtUsername.Text <> "") And (pass.Length >= 8) Then

            btnRegister.Enabled = True
        Else
            btnRegister.Enabled = False
        End If

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        Dim Home As frmHome
        Home = New frmHome

        txtFname.Clear()
        txtMidName.Clear()
        txtLname.Clear()
        txtContactNo.Clear()
        txtAddress.Clear()
        dtpBirthdate.ResetText()
        txtUsername.Clear()
        txtPassword.Clear()

        Me.Hide()
        Home.Show()
    End Sub

    Private Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click

        If cboPriority.SelectedIndex = 0 Then
            priolevel = "A1"
        ElseIf cboPriority.SelectedIndex = 1 Then
            priolevel = "A2"
        ElseIf cboPriority.SelectedIndex = 2 Then
            priolevel = "A3"
        ElseIf cboPriority.SelectedIndex = 3 Then
            priolevel = "A4"
        ElseIf cboPriority.SelectedIndex = 4 Then
            priolevel = "A5"
        ElseIf cboPriority.SelectedIndex = 5 Then
            priolevel = "B1"
        ElseIf cboPriority.SelectedIndex = 6 Then
            priolevel = "B2"
        ElseIf cboPriority.SelectedIndex = 7 Then
            priolevel = "B3"
        ElseIf cboPriority.SelectedIndex = 8 Then
            priolevel = "B4"
        ElseIf cboPriority.SelectedIndex = 9 Then
            priolevel = "B5"
        ElseIf cboPriority.SelectedIndex = 10 Then
            priolevel = "B6"
        ElseIf cboPriority.SelectedIndex = 11 Then
            priolevel = "C1"
        End If

        Dim connection As SqlConnection = New SqlConnection("Data Source=CLARISSEALGASER\SQLEXPRESS;Initial Catalog=dbVaccineRegistry;Integrated Security=True")
        Dim searchUsername As SqlCommand = New SqlCommand("SELECT [username] FROM [dbo].[tbl_register] WHERE [username] COLLATE SQL_Latin1_General_CP1_CS_AS = '" + txtUsername.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS ", connection)


        connection.Open()

        checkUsername = searchUsername.ExecuteScalar

        searchUsername.ExecuteNonQuery()
        connection.Close()

        If txtUsername.Text = checkUsername Then
            MessageBox.Show("Username is already taken", "UNIQUE USERNAME REQUIRED", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Else

            Dim ask As DialogResult = MessageBox.Show("All details provided are correct", "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
            If ask = DialogResult.Yes Then

                Dim idType As String = cboTypeid.SelectedItem.ToString
                Dim gender As String = cboGender.SelectedItem.ToString
                Dim birthdate As String = dtpBirthdate.Value.ToShortDateString

                Dim newconn As SqlConnection = New SqlConnection("Data Source=CLARISSEALGASER\SQLEXPRESS;Initial Catalog=dbVaccineRegistry;Integrated Security=True")
                Dim cmd As SqlCommand = New SqlCommand("INSERT INTO [dbo].[tbl_register]([id_type],[last_name],[first_name],[middle_name],[username],[password],[birthdate],[gender],[address],[contactno],[prio_level]) 
             VALUES('" + idType + "','" + txtLname.Text + "','" + txtFname.Text + "','" + txtMidName.Text + "','" + txtUsername.Text + "','" + txtPassword.Text + "','" + birthdate + "','" + gender + "','" + txtAddress.Text + "','" + txtContactNo.Text + "','" + priolevel + "')", newconn)

                newconn.Open()
                cmd.ExecuteNonQuery()
                newconn.Close()

                Dim confirmation As DialogResult = MessageBox.Show("Registered successfully!", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Information)
                If confirmation = DialogResult.OK Then
                    Dim logIn As frmLogin
                    logIn = New frmLogin
                    Me.Hide()
                    logIn.Show()
                End If
            End If
        End If

    End Sub


End Class