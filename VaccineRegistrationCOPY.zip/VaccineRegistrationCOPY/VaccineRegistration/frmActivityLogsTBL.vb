﻿Imports System.Data
Imports System.Data.SqlClient
Public Class frmActivityLogsTBL

    Public Property adminLogIn As String

    Public userType As String

    Dim adminActivity As String



    Private Sub tmrActivityLogs_Tick(sender As Object, e As EventArgs) Handles tmrActivityLogs.Tick

        lblTime.Text = DateTime.Now

    End Sub



    Private Sub frmLogsTable_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ShowLogsTable()

    End Sub



    Private Sub ShowLogsTable()

        Dim connection As SqlConnection = New SqlConnection("Data Source=CLARISSEALGASER\SQLEXPRESS;Initial Catalog=dbVaccineRegistry;Integrated Security=True")

        Dim showTable As New SqlCommand("SELECT * FROM [dbo].[tbl_logs] ", connection)

        Dim adapter As New SqlDataAdapter(showTable)

        Dim table As New DataTable

        adapter.Fill(table)

        dgvLogsTBL.DataSource = table

    End Sub



    Private Sub btnReturnn_Click(sender As Object, e As EventArgs) Handles btnReturnn.Click
        Dim Admin As frmAdmin
        Admin = New frmAdmin
        frmAdmin.Show()
        Me.Hide()
    End Sub


    Private Sub btnLogOut_Click(sender As Object, e As EventArgs) Handles btnLogOut.Click

        adminActivity = "Viewed Activity Logs Table"

        Dim question As DialogResult = MessageBox.Show("Are you sure you want to log-out?", "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If question = DialogResult.Yes Then

            Dim conn As SqlConnection = New SqlConnection("Data Source=CLARISSEALGASER\SQLEXPRESS;Initial Catalog=dbVaccineRegistry;Integrated Security=True")
            Dim updateAdminTimeOutLog As SqlCommand = New SqlCommand("UPDATE [dbo].[tbl_logs] SET [activity] = '" + adminActivity + "', [log_out] = '" + DateTime.Now.ToString + "' WHERE [username] = '" + userType + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [log_in] = '" + adminLogIn + "'", conn)

            conn.Open()
            updateAdminTimeOutLog.ExecuteNonQuery()
            conn.Close()

            Dim Home As frmHome
            Home = New frmHome

            Me.Close()
            Home.Show()

        End If


    End Sub


End Class