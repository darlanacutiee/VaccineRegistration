﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmActivityLogsTBL
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.dgvLogsTBL = New System.Windows.Forms.DataGridView()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblTime = New System.Windows.Forms.Label()
        Me.btnReturnn = New System.Windows.Forms.Button()
        Me.btnReturn = New System.Windows.Forms.Panel()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.tmrActivityLogs = New System.Windows.Forms.Timer(Me.components)
        Me.btnLogOut = New System.Windows.Forms.Button()
        CType(Me.dgvLogsTBL, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.btnReturn.SuspendLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvLogsTBL
        '
        Me.dgvLogsTBL.AllowUserToAddRows = False
        Me.dgvLogsTBL.AllowUserToDeleteRows = False
        Me.dgvLogsTBL.AllowUserToResizeColumns = False
        Me.dgvLogsTBL.AllowUserToResizeRows = False
        Me.dgvLogsTBL.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgvLogsTBL.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgvLogsTBL.BackgroundColor = System.Drawing.Color.White
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvLogsTBL.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle3
        Me.dgvLogsTBL.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvLogsTBL.DefaultCellStyle = DataGridViewCellStyle4
        Me.dgvLogsTBL.Location = New System.Drawing.Point(156, 112)
        Me.dgvLogsTBL.Name = "dgvLogsTBL"
        Me.dgvLogsTBL.ReadOnly = True
        Me.dgvLogsTBL.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders
        Me.dgvLogsTBL.Size = New System.Drawing.Size(643, 376)
        Me.dgvLogsTBL.TabIndex = 129
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.btnLogOut)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Controls.Add(Me.lblTime)
        Me.Panel2.Location = New System.Drawing.Point(156, 9)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(643, 74)
        Me.Panel2.TabIndex = 128
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Tai Le", 20.0!)
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(175, 38)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(276, 34)
        Me.Label1.TabIndex = 131
        Me.Label1.Text = "ACTIVITY LOGS TABLE"
        '
        'lblTime
        '
        Me.lblTime.AutoSize = True
        Me.lblTime.BackColor = System.Drawing.Color.Transparent
        Me.lblTime.Font = New System.Drawing.Font("Microsoft Tai Le", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTime.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblTime.Location = New System.Drawing.Point(293, 6)
        Me.lblTime.Name = "lblTime"
        Me.lblTime.Size = New System.Drawing.Size(17, 16)
        Me.lblTime.TabIndex = 127
        Me.lblTime.Text = "--"
        '
        'btnReturnn
        '
        Me.btnReturnn.BackColor = System.Drawing.Color.DarkGoldenrod
        Me.btnReturnn.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnReturnn.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReturnn.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnReturnn.Location = New System.Drawing.Point(6, 442)
        Me.btnReturnn.Name = "btnReturnn"
        Me.btnReturnn.Size = New System.Drawing.Size(126, 30)
        Me.btnReturnn.TabIndex = 131
        Me.btnReturnn.Text = "Return"
        Me.btnReturnn.UseVisualStyleBackColor = False
        '
        'btnReturn
        '
        Me.btnReturn.BackColor = System.Drawing.SystemColors.ControlLight
        Me.btnReturn.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.btnReturn.Controls.Add(Me.PictureBox4)
        Me.btnReturn.Controls.Add(Me.btnReturnn)
        Me.btnReturn.Controls.Add(Me.Label4)
        Me.btnReturn.Location = New System.Drawing.Point(4, 9)
        Me.btnReturn.Name = "btnReturn"
        Me.btnReturn.Size = New System.Drawing.Size(145, 479)
        Me.btnReturn.TabIndex = 127
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.SystemColors.ControlLight
        Me.PictureBox4.Image = Global.VaccineRegistration.My.Resources.Resources.G8
        Me.PictureBox4.Location = New System.Drawing.Point(21, 57)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(96, 79)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 134
        Me.PictureBox4.TabStop = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.Font = New System.Drawing.Font("Microsoft Tai Le", 20.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label4.Location = New System.Drawing.Point(15, 6)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(102, 34)
        Me.Label4.TabIndex = 130
        Me.Label4.Text = "ADMIN"
        '
        'tmrActivityLogs
        '
        Me.tmrActivityLogs.Enabled = True
        Me.tmrActivityLogs.Interval = 1000
        '
        'btnLogOut
        '
        Me.btnLogOut.BackColor = System.Drawing.SystemColors.ControlLight
        Me.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnLogOut.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!)
        Me.btnLogOut.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnLogOut.Location = New System.Drawing.Point(548, 6)
        Me.btnLogOut.Name = "btnLogOut"
        Me.btnLogOut.Size = New System.Drawing.Size(88, 22)
        Me.btnLogOut.TabIndex = 134
        Me.btnLogOut.Text = "Log out"
        Me.btnLogOut.UseVisualStyleBackColor = False
        '
        'frmActivityLogsTBL
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(813, 496)
        Me.ControlBox = False
        Me.Controls.Add(Me.dgvLogsTBL)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.btnReturn)
        Me.Name = "frmActivityLogsTBL"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.dgvLogsTBL, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.btnReturn.ResumeLayout(False)
        Me.btnReturn.PerformLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents dgvLogsTBL As DataGridView
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents lblTime As Label
    Friend WithEvents btnReturnn As Button
    Friend WithEvents btnReturn As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents tmrActivityLogs As Timer
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents btnLogOut As Button
End Class
