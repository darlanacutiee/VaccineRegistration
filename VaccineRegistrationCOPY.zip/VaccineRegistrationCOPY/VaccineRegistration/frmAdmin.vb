﻿Imports System.Data
Imports System.Data.SqlClient
Public Class frmAdmin

    Public Property adminLogIn As String
    Public userType As String
    Dim adminActivity As String

    Private Sub tmrAdmin_Tick(sender As Object, e As EventArgs) Handles tmrAdmin.Tick

        lblTime.Text = DateTime.Now

        If txtLastname.Text <> "" Then
            btnSearch.Enabled = True
        Else
            btnSearch.Enabled = False
        End If

    End Sub



    Private Sub frmAdmin_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        countTracker()

    End Sub



    Private Sub countTracker()


        Dim connection As SqlConnection = New SqlConnection("Data Source=CLARISSEALGASER\SQLEXPRESS;Initial Catalog=dbVaccineRegistry;Integrated Security=True")

        Using countAccounts As SqlCommand = New SqlCommand("SELECT COUNT([regis_id]) FROM [dbo].[tbl_register] ", connection)
            Using countAppointments As SqlCommand = New SqlCommand("SELECT COUNT([appointmentid]) FROM [dbo].[tbl_appointment] ", connection)
                Using count1stDose As SqlCommand = New SqlCommand("SELECT COUNT([vaccine_dose]) FROM [dbo].[tbl_appointment] WHERE [vaccine_dose] = '" + "1st Dose" + "' ", connection)
                    Using count2ndDose As SqlCommand = New SqlCommand("SELECT COUNT([vaccine_dose]) FROM [dbo].[tbl_appointment] WHERE [vaccine_dose] = '" + "2nd Dose" + "' ", connection)
                        Using countPfizer As SqlCommand = New SqlCommand("SELECT COUNT([vaccine_brand]) FROM [dbo].[tbl_appointment] WHERE [vaccine_brand] = '" + "Pfizer" + "' ", connection)
                            Using countModerna As SqlCommand = New SqlCommand("SELECT COUNT([vaccine_brand]) FROM [dbo].[tbl_appointment] WHERE [vaccine_brand] = '" + "Moderna" + "' ", connection)
                                Using countAstra As SqlCommand = New SqlCommand("SELECT COUNT([vaccine_brand]) FROM [dbo].[tbl_appointment] WHERE [vaccine_brand] = '" + "AstraZeneca" + "' ", connection)
                                    Using countSputnik As SqlCommand = New SqlCommand("SELECT COUNT([vaccine_brand]) FROM [dbo].[tbl_appointment] WHERE [vaccine_brand] = '" + "Sputnik V" + "' ", connection)
                                        Using countJohnson As SqlCommand = New SqlCommand("SELECT COUNT([vaccine_brand]) FROM [dbo].[tbl_appointment] WHERE [vaccine_brand] = '" + "Johnson & Johnson" + "' ", connection)
                                            Using countMorning As SqlCommand = New SqlCommand("SELECT COUNT([timeslot]) FROM [dbo].[tbl_appointment] WHERE [timeslot] = '" + "7:00 AM - 9:00 AM" + "' ", connection)
                                                Using countAfternoon As SqlCommand = New SqlCommand("SELECT COUNT([timeslot]) FROM [dbo].[tbl_appointment] WHERE [timeslot] = '" + "1:00 PM - 3:00 PM" + "' ", connection)

                                                    connection.Open()
                                                    txtAccount.Text = countAccounts.ExecuteScalar()
                                                    txtTotalAppointments.Text = countAppointments.ExecuteScalar()
                                                    txt1stDose.Text = count1stDose.ExecuteScalar()
                                                    txt2ndDose.Text = count2ndDose.ExecuteScalar()
                                                    txtPfizer.Text = countPfizer.ExecuteScalar()
                                                    txtModerna.Text = countModerna.ExecuteScalar()
                                                    txtAstrazeneca.Text = countAstra.ExecuteScalar()
                                                    txtSputnik.Text = countSputnik.ExecuteScalar()
                                                    txtJJ.Text = countJohnson.ExecuteScalar()
                                                    txtMorning.Text = countMorning.ExecuteScalar()
                                                    txtAfternoon.Text = countAfternoon.ExecuteScalar()
                                                    connection.Close()

                                                End Using
                                            End Using
                                        End Using
                                    End Using
                                End Using
                            End Using
                        End Using
                    End Using
                End Using
            End Using
        End Using

    End Sub



    Private Sub btnCount_Click(sender As Object, e As EventArgs) Handles btnCount.Click

        countTracker()

    End Sub




    Private Sub btnVUser_Click(sender As Object, e As EventArgs) Handles btnVUser.Click

        Dim userTable As frmUserAccountTBL
        userTable = New frmUserAccountTBL

        userTable.Show()
        Me.Hide()

    End Sub



    Private Sub btnVAppointments_Click(sender As Object, e As EventArgs) Handles btnVAppointments.Click

        Dim apppointmentsTbl As frmAppointmentTBL
        apppointmentsTbl = New frmAppointmentTBL

        apppointmentsTbl.Show()
        Me.Hide()

    End Sub




    Private Sub btnVLogs_Click(sender As Object, e As EventArgs) Handles btnVLogs.Click

        Dim logsTable As frmActivityLogsTBL
        logsTable = New frmActivityLogsTBL

        logsTable.Show()
        Me.Hide()

    End Sub




    Private Sub btnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click

        searchByLastName()

    End Sub




    Private Sub searchByLastName()

        Dim Lastname As String

        Lastname = txtLastname.Text

        Dim connection As SqlConnection = New SqlConnection("Data Source=CLARISSEALGASER\SQLEXPRESS;Initial Catalog=dbVaccineRegistry;Integrated Security=True")

        Dim showTable As New SqlCommand("SELECT * FROM [dbo].[tbl_register] WHERE [last_name] = '" + Lastname + "' ", connection)

        Dim adapter As New SqlDataAdapter(showTable)

        Dim table As New DataTable

        adapter.Fill(table)

        dgvSearchTBL.DataSource = table

    End Sub




    Private Sub btnLogOut_Click(sender As Object, e As EventArgs) Handles btnLogOut.Click

        adminActivity = "File Maintenance"

        Dim question As DialogResult = MessageBox.Show("Are you sure you want to log-out?", "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If question = DialogResult.Yes Then

            Dim conn As SqlConnection = New SqlConnection("Data Source=CLARISSEALGASER\SQLEXPRESS;Initial Catalog=dbVaccineRegistry;Integrated Security=True")
            Dim updateAdminTimeOutLog As SqlCommand = New SqlCommand("UPDATE [dbo].[tbl_logs] SET [activity] = '" + adminActivity + "', [log_out] = '" + DateTime.Now.ToString + "' WHERE [username] = '" + userType + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [log_in] = '" + adminLogIn + "'", conn)

            conn.Open()
            updateAdminTimeOutLog.ExecuteNonQuery()
            conn.Close()

            Dim Home As frmHome
            Home = New frmHome

            Me.Close()
            Home.Show()

        End If

    End Sub



    Private Sub dgvSearchTable_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles dgvSearchTBL.CellContentClick

    End Sub


End Class