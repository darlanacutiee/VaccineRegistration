﻿Imports System.Data
Imports System.Data.SqlClient


Public Class frmAppointment

    Dim registrationId, vaccine, venue, time, scheduledate, dose As String


    Private Sub tmrAppointment_Tick(sender As Object, e As EventArgs) Handles tmrAppointment.Tick

        lblTime.Text = DateTime.Now
        dtpDate.MinDate = DateTime.Today.AddDays(1)
        dtpDate.MinDate = New DateTime(DateTime.Now.Year, DateTime.Now.Month, 1)
        dtpDate.MaxDate = dtpDate.MinDate.AddMonths(2)

        If txtRegisno.Text = "" Or cboVaccine.SelectedIndex = -1 Or
            cboVenue.SelectedIndex = -1 Or cboTimeSlot.SelectedIndex = -1 Or cboDose.SelectedIndex = -1 Then
            btnBook.Enabled = False
        Else
            btnBook.Enabled = True

        End If

    End Sub



    Private Sub btnBook_Click(sender As Object, e As EventArgs) Handles btnBook.Click


        registrationId = txtRegisno.Text

        If cboVaccine.SelectedIndex = 0 Then
            vaccine = "Pfizer"
        ElseIf cboVaccine.SelectedIndex = 1 Then
            vaccine = "AstraZeneca"
        ElseIf cboVaccine.SelectedIndex = 2 Then
            vaccine = "Sinovac"
        ElseIf cboVaccine.SelectedIndex = 3 Then
            vaccine = "Sputnik V"
        ElseIf cboVaccine.SelectedIndex = 4 Then
            vaccine = "Johnson & Johnsons"
        ElseIf cboVaccine.SelectedIndex = 5 Then
            vaccine = "Moderna"
        End If

        If cboVenue.SelectedIndex = 0 Then
            venue = "City Hall Quadrangle"
        ElseIf cboVenue.SelectedIndex = 1 Then
            venue = "East Rembo Elementary School"
        ElseIf cboVenue.SelectedIndex = 2 Then
            venue = "Makati High School"
        End If

        If cboTimeSlot.SelectedIndex = 0 Then
            time = "7:00 AM - 9:00 AM"
        ElseIf cboTimeSlot.SelectedIndex = 1 Then
            time = "1:00 PM - 3:00 PM"
        End If


        If cboDose.SelectedIndex = 0 Then
            dose = "1st Dose"
        ElseIf cboDose.SelectedIndex = 1 Then
            dose = "2nd Dose"
        End If

        scheduledate = dtpDate.Value.ToShortDateString


        Dim question As DialogResult = MessageBox.Show("Are all fields filled-up correctly?", "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If question = DialogResult.Yes Then

            Dim connection As SqlConnection = New SqlConnection("Data Source=CLARISSEALGASER\SQLEXPRESS;Initial Catalog=dbVaccineRegistry;Integrated Security=True")
            Dim insertIntoAppointmentsTableCmd As SqlCommand = New SqlCommand("INSERT INTO [dbo].[tbl_appointment]([vaccine_brand],[vaccine_dose],[date],[timeslot],[venue],[regis_id])
                VALUES('" + vaccine + "','" + dose + "','" + scheduledate + "','" + time + "','" + venue + "','" + registrationId + "')", connection)

            connection.Open()
            insertIntoAppointmentsTableCmd.ExecuteNonQuery()
            connection.Close()

            If cboDose.SelectedIndex = 0 Then

                Dim connection2 As SqlConnection = New SqlConnection("Data Source=CLARISSEALGASER\SQLEXPRESS;Initial Catalog=dbVaccineRegistry;Integrated Security=True")
                Dim editFirstDoseDateCmd As SqlCommand = New SqlCommand("UPDATE [dbo].[tbl_register] SET [first_dose] = '" + scheduledate + "' WHERE [regis_id] = '" + registrationId + "'", connection2)

                connection2.Open()
                editFirstDoseDateCmd.ExecuteNonQuery()
                connection2.Close()

            ElseIf cboDose.SelectedIndex = 1 Then


                Dim connection3 As SqlConnection = New SqlConnection("Data Source=CLARISSEALGASER\SQLEXPRESS;Initial Catalog=dbVaccineRegistry;Integrated Security=True")
                Dim editSecondtDoseDateCmd As SqlCommand = New SqlCommand("UPDATE [dbo].[tbl_register] SET [second_dose] = '" + scheduledate + "' WHERE [regis_id] = '" + registrationId + "'", connection3)

                connection3.Open()
                editSecondtDoseDateCmd.ExecuteNonQuery()
                connection3.Close()

            End If
            MessageBox.Show("Your appointment has been scheduled.", "INFORMATION", MessageBoxButtons.OK, MessageBoxIcon.Information)

            Dim User As frmUser
            User = New frmUser
            Refresh()
            Me.Close()
            User.Show()


        ElseIf question = DialogResult.No Then
            MessageBox.Show(MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If

    End Sub

End Class