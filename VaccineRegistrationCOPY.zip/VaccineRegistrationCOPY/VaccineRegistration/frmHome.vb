﻿Public Class frmHome


    Private Sub btnRegister_Click(ByVal sender As System.Object, e As System.EventArgs) Handles btnRegister.Click
        Dim Register As frmRegister
        Register = New frmRegister

        Register.Show()
        Me.Hide()

    End Sub


    Private Sub btnLogIn_Click(ByVal sender As System.Object, e As System.EventArgs) Handles btnLogIn.Click
        Dim LogIn As frmLogIn
        LogIn = New frmLogIn

        LogIn.Show()
        Me.Hide()

    End Sub


    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click

        Application.Exit()

    End Sub
End Class
