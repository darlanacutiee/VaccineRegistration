﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmAdmin
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.dgvSearchTBL = New System.Windows.Forms.DataGridView()
        Me.btnSearch = New System.Windows.Forms.Button()
        Me.txtLastname = New System.Windows.Forms.TextBox()
        Me.btnCount = New System.Windows.Forms.Button()
        Me.btnVLogs = New System.Windows.Forms.Button()
        Me.btnVAppointments = New System.Windows.Forms.Button()
        Me.btnVUser = New System.Windows.Forms.Button()
        Me.btnLogOut = New System.Windows.Forms.Button()
        Me.lblTime = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.txtAccount = New System.Windows.Forms.TextBox()
        Me.txt1stDose = New System.Windows.Forms.TextBox()
        Me.txt2ndDose = New System.Windows.Forms.TextBox()
        Me.txtPfizer = New System.Windows.Forms.TextBox()
        Me.txtModerna = New System.Windows.Forms.TextBox()
        Me.txtJJ = New System.Windows.Forms.TextBox()
        Me.txtAstrazeneca = New System.Windows.Forms.TextBox()
        Me.txtSputnik = New System.Windows.Forms.TextBox()
        Me.txtAfternoon = New System.Windows.Forms.TextBox()
        Me.txtMorning = New System.Windows.Forms.TextBox()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.tmrAdmin = New System.Windows.Forms.Timer(Me.components)
        Me.Button3 = New System.Windows.Forms.Button()
        Me.txtTotalAppointments = New System.Windows.Forms.TextBox()
        CType(Me.dgvSearchTBL, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvSearchTBL
        '
        Me.dgvSearchTBL.AllowUserToAddRows = False
        Me.dgvSearchTBL.AllowUserToDeleteRows = False
        Me.dgvSearchTBL.AllowUserToResizeColumns = False
        Me.dgvSearchTBL.AllowUserToResizeRows = False
        Me.dgvSearchTBL.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells
        Me.dgvSearchTBL.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells
        Me.dgvSearchTBL.BackgroundColor = System.Drawing.Color.White
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.dgvSearchTBL.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvSearchTBL.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.749999!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText
        DataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.dgvSearchTBL.DefaultCellStyle = DataGridViewCellStyle2
        Me.dgvSearchTBL.Location = New System.Drawing.Point(183, 120)
        Me.dgvSearchTBL.Name = "dgvSearchTBL"
        Me.dgvSearchTBL.ReadOnly = True
        Me.dgvSearchTBL.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToAllHeaders
        Me.dgvSearchTBL.Size = New System.Drawing.Size(918, 139)
        Me.dgvSearchTBL.TabIndex = 125
        '
        'btnSearch
        '
        Me.btnSearch.BackColor = System.Drawing.Color.White
        Me.btnSearch.Enabled = False
        Me.btnSearch.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnSearch.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSearch.ForeColor = System.Drawing.Color.Black
        Me.btnSearch.Location = New System.Drawing.Point(486, 87)
        Me.btnSearch.Name = "btnSearch"
        Me.btnSearch.Size = New System.Drawing.Size(100, 30)
        Me.btnSearch.TabIndex = 120
        Me.btnSearch.Text = "Search"
        Me.btnSearch.UseVisualStyleBackColor = False
        '
        'txtLastname
        '
        Me.txtLastname.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLastname.Location = New System.Drawing.Point(279, 89)
        Me.txtLastname.Name = "txtLastname"
        Me.txtLastname.Size = New System.Drawing.Size(201, 28)
        Me.txtLastname.TabIndex = 0
        Me.txtLastname.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnCount
        '
        Me.btnCount.BackColor = System.Drawing.Color.DarkGoldenrod
        Me.btnCount.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnCount.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCount.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnCount.Location = New System.Drawing.Point(9, 307)
        Me.btnCount.Name = "btnCount"
        Me.btnCount.Size = New System.Drawing.Size(145, 30)
        Me.btnCount.TabIndex = 123
        Me.btnCount.Text = "Count"
        Me.btnCount.UseVisualStyleBackColor = False
        '
        'btnVLogs
        '
        Me.btnVLogs.BackColor = System.Drawing.Color.GhostWhite
        Me.btnVLogs.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnVLogs.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnVLogs.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnVLogs.Location = New System.Drawing.Point(9, 267)
        Me.btnVLogs.Name = "btnVLogs"
        Me.btnVLogs.Size = New System.Drawing.Size(143, 30)
        Me.btnVLogs.TabIndex = 120
        Me.btnVLogs.Text = "Activity Logs"
        Me.btnVLogs.UseVisualStyleBackColor = False
        '
        'btnVAppointments
        '
        Me.btnVAppointments.BackColor = System.Drawing.Color.GhostWhite
        Me.btnVAppointments.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnVAppointments.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnVAppointments.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnVAppointments.Location = New System.Drawing.Point(9, 228)
        Me.btnVAppointments.Name = "btnVAppointments"
        Me.btnVAppointments.Size = New System.Drawing.Size(143, 30)
        Me.btnVAppointments.TabIndex = 119
        Me.btnVAppointments.Text = "Appointment"
        Me.btnVAppointments.UseVisualStyleBackColor = False
        '
        'btnVUser
        '
        Me.btnVUser.BackColor = System.Drawing.Color.GhostWhite
        Me.btnVUser.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnVUser.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnVUser.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnVUser.Location = New System.Drawing.Point(9, 189)
        Me.btnVUser.Name = "btnVUser"
        Me.btnVUser.Size = New System.Drawing.Size(143, 30)
        Me.btnVUser.TabIndex = 118
        Me.btnVUser.Text = "User Account"
        Me.btnVUser.UseVisualStyleBackColor = False
        '
        'btnLogOut
        '
        Me.btnLogOut.BackColor = System.Drawing.SystemColors.ControlLight
        Me.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnLogOut.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!)
        Me.btnLogOut.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnLogOut.Location = New System.Drawing.Point(845, 12)
        Me.btnLogOut.Name = "btnLogOut"
        Me.btnLogOut.Size = New System.Drawing.Size(88, 22)
        Me.btnLogOut.TabIndex = 120
        Me.btnLogOut.Text = "Log out"
        Me.btnLogOut.UseVisualStyleBackColor = False
        '
        'lblTime
        '
        Me.lblTime.AutoSize = True
        Me.lblTime.BackColor = System.Drawing.Color.Transparent
        Me.lblTime.Font = New System.Drawing.Font("Microsoft Tai Le", 10.0!)
        Me.lblTime.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblTime.Location = New System.Drawing.Point(445, 0)
        Me.lblTime.Name = "lblTime"
        Me.lblTime.Size = New System.Drawing.Size(20, 18)
        Me.lblTime.TabIndex = 126
        Me.lblTime.Text = "--"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label2.Location = New System.Drawing.Point(189, 91)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(84, 20)
        Me.Label2.TabIndex = 127
        Me.Label2.Text = "Lastname:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label3.Location = New System.Drawing.Point(7, 165)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(52, 21)
        Me.Label3.TabIndex = 128
        Me.Label3.Text = "Show:"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.Info
        Me.Button1.Enabled = False
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button1.Location = New System.Drawing.Point(289, 331)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(170, 47)
        Me.Button1.TabIndex = 131
        Me.Button1.Text = "No. of Users who booked an Appointment for 1st Dose"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.SystemColors.Info
        Me.Button2.Enabled = False
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(289, 384)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(170, 47)
        Me.Button2.TabIndex = 132
        Me.Button2.Text = "No. of Users who booked an Appointment for 2nd Dose"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.SystemColors.Info
        Me.Button4.Enabled = False
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(289, 276)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(111, 47)
        Me.Button4.TabIndex = 134
        Me.Button4.Text = "Total No. of Accounts"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.SystemColors.Info
        Me.Button5.Enabled = False
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.Location = New System.Drawing.Point(614, 276)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(167, 47)
        Me.Button5.TabIndex = 135
        Me.Button5.Text = "No. of Users preferred Pfizer"
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.SystemColors.Info
        Me.Button6.Enabled = False
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button6.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.Location = New System.Drawing.Point(614, 331)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(167, 47)
        Me.Button6.TabIndex = 136
        Me.Button6.Text = "No. of Users preferred Moderna Vaccine"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Button7
        '
        Me.Button7.BackColor = System.Drawing.SystemColors.Info
        Me.Button7.Enabled = False
        Me.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button7.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.Location = New System.Drawing.Point(614, 437)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(167, 47)
        Me.Button7.TabIndex = 137
        Me.Button7.Text = "No. of Users preferred AstraZeneca"
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.BackColor = System.Drawing.SystemColors.Info
        Me.Button8.Enabled = False
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button8.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.Location = New System.Drawing.Point(614, 490)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(167, 47)
        Me.Button8.TabIndex = 138
        Me.Button8.Text = "No. of Users preferred Sputnik V"
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Button9
        '
        Me.Button9.BackColor = System.Drawing.SystemColors.Info
        Me.Button9.Enabled = False
        Me.Button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button9.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.Location = New System.Drawing.Point(614, 384)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(167, 47)
        Me.Button9.TabIndex = 139
        Me.Button9.Text = "No. of Users preferred Johnson and Johnson's"
        Me.Button9.UseVisualStyleBackColor = False
        '
        'txtAccount
        '
        Me.txtAccount.Enabled = False
        Me.txtAccount.Font = New System.Drawing.Font("Microsoft Tai Le", 24.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAccount.ForeColor = System.Drawing.Color.Firebrick
        Me.txtAccount.Location = New System.Drawing.Point(183, 276)
        Me.txtAccount.Name = "txtAccount"
        Me.txtAccount.Size = New System.Drawing.Size(100, 49)
        Me.txtAccount.TabIndex = 143
        Me.txtAccount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt1stDose
        '
        Me.txt1stDose.Enabled = False
        Me.txt1stDose.Font = New System.Drawing.Font("Microsoft Tai Le", 24.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt1stDose.ForeColor = System.Drawing.Color.Firebrick
        Me.txt1stDose.Location = New System.Drawing.Point(183, 331)
        Me.txt1stDose.Name = "txt1stDose"
        Me.txt1stDose.Size = New System.Drawing.Size(100, 49)
        Me.txt1stDose.TabIndex = 144
        Me.txt1stDose.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt2ndDose
        '
        Me.txt2ndDose.Enabled = False
        Me.txt2ndDose.Font = New System.Drawing.Font("Microsoft Tai Le", 24.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt2ndDose.ForeColor = System.Drawing.Color.Firebrick
        Me.txt2ndDose.Location = New System.Drawing.Point(183, 384)
        Me.txt2ndDose.Name = "txt2ndDose"
        Me.txt2ndDose.Size = New System.Drawing.Size(100, 49)
        Me.txt2ndDose.TabIndex = 145
        Me.txt2ndDose.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtPfizer
        '
        Me.txtPfizer.Enabled = False
        Me.txtPfizer.Font = New System.Drawing.Font("Microsoft Tai Le", 24.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPfizer.ForeColor = System.Drawing.Color.Firebrick
        Me.txtPfizer.Location = New System.Drawing.Point(508, 278)
        Me.txtPfizer.Name = "txtPfizer"
        Me.txtPfizer.Size = New System.Drawing.Size(100, 49)
        Me.txtPfizer.TabIndex = 147
        Me.txtPfizer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtModerna
        '
        Me.txtModerna.Enabled = False
        Me.txtModerna.Font = New System.Drawing.Font("Microsoft Tai Le", 24.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtModerna.ForeColor = System.Drawing.Color.Firebrick
        Me.txtModerna.Location = New System.Drawing.Point(508, 331)
        Me.txtModerna.Name = "txtModerna"
        Me.txtModerna.Size = New System.Drawing.Size(100, 49)
        Me.txtModerna.TabIndex = 148
        Me.txtModerna.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtJJ
        '
        Me.txtJJ.Enabled = False
        Me.txtJJ.Font = New System.Drawing.Font("Microsoft Tai Le", 24.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtJJ.ForeColor = System.Drawing.Color.Firebrick
        Me.txtJJ.Location = New System.Drawing.Point(508, 384)
        Me.txtJJ.Name = "txtJJ"
        Me.txtJJ.Size = New System.Drawing.Size(100, 49)
        Me.txtJJ.TabIndex = 149
        Me.txtJJ.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtAstrazeneca
        '
        Me.txtAstrazeneca.Enabled = False
        Me.txtAstrazeneca.Font = New System.Drawing.Font("Microsoft Tai Le", 24.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAstrazeneca.ForeColor = System.Drawing.Color.Firebrick
        Me.txtAstrazeneca.Location = New System.Drawing.Point(508, 437)
        Me.txtAstrazeneca.Name = "txtAstrazeneca"
        Me.txtAstrazeneca.Size = New System.Drawing.Size(100, 49)
        Me.txtAstrazeneca.TabIndex = 150
        Me.txtAstrazeneca.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtSputnik
        '
        Me.txtSputnik.Enabled = False
        Me.txtSputnik.Font = New System.Drawing.Font("Microsoft Tai Le", 24.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSputnik.ForeColor = System.Drawing.Color.Firebrick
        Me.txtSputnik.Location = New System.Drawing.Point(508, 490)
        Me.txtSputnik.Name = "txtSputnik"
        Me.txtSputnik.Size = New System.Drawing.Size(100, 49)
        Me.txtSputnik.TabIndex = 151
        Me.txtSputnik.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtAfternoon
        '
        Me.txtAfternoon.Enabled = False
        Me.txtAfternoon.Font = New System.Drawing.Font("Microsoft Tai Le", 24.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAfternoon.ForeColor = System.Drawing.Color.Firebrick
        Me.txtAfternoon.Location = New System.Drawing.Point(825, 329)
        Me.txtAfternoon.Name = "txtAfternoon"
        Me.txtAfternoon.Size = New System.Drawing.Size(100, 49)
        Me.txtAfternoon.TabIndex = 155
        Me.txtAfternoon.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtMorning
        '
        Me.txtMorning.Enabled = False
        Me.txtMorning.Font = New System.Drawing.Font("Microsoft Tai Le", 24.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMorning.ForeColor = System.Drawing.Color.Firebrick
        Me.txtMorning.Location = New System.Drawing.Point(825, 278)
        Me.txtMorning.Name = "txtMorning"
        Me.txtMorning.Size = New System.Drawing.Size(100, 49)
        Me.txtMorning.TabIndex = 154
        Me.txtMorning.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Button10
        '
        Me.Button10.BackColor = System.Drawing.SystemColors.Info
        Me.Button10.Enabled = False
        Me.Button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button10.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.Location = New System.Drawing.Point(931, 276)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(167, 47)
        Me.Button10.TabIndex = 153
        Me.Button10.Text = "Users Preferred Morning Schedule"
        Me.Button10.UseVisualStyleBackColor = False
        '
        'Button11
        '
        Me.Button11.BackColor = System.Drawing.SystemColors.Info
        Me.Button11.Enabled = False
        Me.Button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button11.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.Location = New System.Drawing.Point(931, 329)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(167, 47)
        Me.Button11.TabIndex = 152
        Me.Button11.Text = "Users Preferred Afternoon Schedule"
        Me.Button11.UseVisualStyleBackColor = False
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.btnLogOut)
        Me.Panel1.Controls.Add(Me.lblTime)
        Me.Panel1.Location = New System.Drawing.Point(165, 9)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(946, 69)
        Me.Panel1.TabIndex = 156
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.PictureBox4)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.btnCount)
        Me.Panel2.Controls.Add(Me.btnVUser)
        Me.Panel2.Controls.Add(Me.btnVLogs)
        Me.Panel2.Controls.Add(Me.btnVAppointments)
        Me.Panel2.Location = New System.Drawing.Point(3, 4)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(162, 565)
        Me.Panel2.TabIndex = 157
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.SystemColors.ControlLight
        Me.PictureBox4.Image = Global.VaccineRegistration.My.Resources.Resources.G8
        Me.PictureBox4.Location = New System.Drawing.Point(27, 54)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(87, 81)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 130
        Me.PictureBox4.TabStop = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Label4.Font = New System.Drawing.Font("Microsoft Tai Le", 20.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.HotTrack
        Me.Label4.Location = New System.Drawing.Point(21, 17)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(102, 34)
        Me.Label4.TabIndex = 129
        Me.Label4.Text = "ADMIN"
        '
        'tmrAdmin
        '
        Me.tmrAdmin.Enabled = True
        Me.tmrAdmin.Interval = 1000
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.SystemColors.Info
        Me.Button3.Enabled = False
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(289, 441)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(170, 47)
        Me.Button3.TabIndex = 158
        Me.Button3.Text = "Total No. of Users who booked an Appointment"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'txtTotalAppointments
        '
        Me.txtTotalAppointments.Enabled = False
        Me.txtTotalAppointments.Font = New System.Drawing.Font("Microsoft Tai Le", 24.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtTotalAppointments.ForeColor = System.Drawing.Color.Firebrick
        Me.txtTotalAppointments.Location = New System.Drawing.Point(183, 439)
        Me.txtTotalAppointments.Name = "txtTotalAppointments"
        Me.txtTotalAppointments.Size = New System.Drawing.Size(100, 49)
        Me.txtTotalAppointments.TabIndex = 159
        Me.txtTotalAppointments.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'frmAdmin
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlDark
        Me.ClientSize = New System.Drawing.Size(1123, 572)
        Me.ControlBox = False
        Me.Controls.Add(Me.txtTotalAppointments)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtLastname)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.btnSearch)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.txtAfternoon)
        Me.Controls.Add(Me.txtMorning)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.txtSputnik)
        Me.Controls.Add(Me.txtAstrazeneca)
        Me.Controls.Add(Me.txtJJ)
        Me.Controls.Add(Me.txtModerna)
        Me.Controls.Add(Me.txtPfizer)
        Me.Controls.Add(Me.txt2ndDose)
        Me.Controls.Add(Me.txt1stDose)
        Me.Controls.Add(Me.txtAccount)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.dgvSearchTBL)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmAdmin"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.dgvSearchTBL, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dgvSearchTBL As DataGridView
    Friend WithEvents btnSearch As Button
    Friend WithEvents txtLastname As TextBox
    Friend WithEvents btnCount As Button
    Friend WithEvents btnVLogs As Button
    Friend WithEvents btnVAppointments As Button
    Friend WithEvents btnVUser As Button
    Friend WithEvents btnLogOut As Button
    Friend WithEvents lblTime As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Button5 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button7 As Button
    Friend WithEvents Button8 As Button
    Friend WithEvents Button9 As Button
    Friend WithEvents txtAccount As TextBox
    Friend WithEvents txt1stDose As TextBox
    Friend WithEvents txt2ndDose As TextBox
    Friend WithEvents txtPfizer As TextBox
    Friend WithEvents txtModerna As TextBox
    Friend WithEvents txtJJ As TextBox
    Friend WithEvents txtAstrazeneca As TextBox
    Friend WithEvents txtSputnik As TextBox
    Friend WithEvents txtAfternoon As TextBox
    Friend WithEvents txtMorning As TextBox
    Friend WithEvents Button10 As Button
    Friend WithEvents Button11 As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label4 As Label
    Friend WithEvents tmrAdmin As Timer
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents Button3 As Button
    Friend WithEvents txtTotalAppointments As TextBox
End Class
