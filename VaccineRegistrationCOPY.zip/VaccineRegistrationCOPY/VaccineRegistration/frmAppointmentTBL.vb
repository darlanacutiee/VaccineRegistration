﻿Imports System.Data
Imports System.Data.SqlClient
Public Class frmAppointmentTBL

    Public Property adminLogIn As String

    Public userType As String

    Dim adminActivity As String


    Private Sub frmAppointmentsTable_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ShowAppointmentsTable()

    End Sub



    Private Sub ShowAppointmentsTable()

        Dim connection As SqlConnection = New SqlConnection("Data Source=CLARISSEALGASER\SQLEXPRESS;Initial Catalog=dbVaccineRegistry;Integrated Security=True")

        Dim showTable As New SqlCommand("SELECT * FROM [dbo].[tbl_appointment] ", connection)

        Dim adapter As New SqlDataAdapter(showTable)

        Dim table As New DataTable

        adapter.Fill(table)

        dgvAppointmentTBL.DataSource = table

    End Sub



    Private Sub btnReturn_Click(sender As Object, e As EventArgs) Handles btnReturn.Click

        Dim Admin As frmAdmin
        Admin = New frmAdmin

        Me.Close()
        Admin.Show()

    End Sub



    Private Sub btnLogOut_Click(sender As Object, e As EventArgs) Handles btnLogOut.Click

        adminActivity = "Viewed Appointments Table"

        Dim question As DialogResult = MessageBox.Show("Are you sure you want to log-out?", "CONFIRMATION", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If question = DialogResult.Yes Then

            Dim conn As SqlConnection = New SqlConnection("Data Source=CLARISSEALGASER\SQLEXPRESS;Initial Catalog=dbVaccineRegistry;Integrated Security=True")
            Dim updateAdminTimeOutLog As SqlCommand = New SqlCommand("UPDATE [dbo].[tbl_logs] SET [activity] = '" + adminActivity + "', [log_out] = '" + DateTime.Now.ToString + "' WHERE [username] = '" + userType + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [log_in] = '" + adminLogIn + "'", conn)

            conn.Open()
            updateAdminTimeOutLog.ExecuteNonQuery()
            conn.Close()

            Dim Home As frmHome
            Home = New frmHome

            Me.Close()
            Home.Show()

        End If

    End Sub


End Class