﻿Imports System.Data
Imports System.Data.SqlClient
Public Class frmUserAccountTBL
    Public Property adminLogIn As String

    Public userType As String

    Dim adminActivity As String
    Private Sub frmUserTable_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ShowUserTable()

    End Sub

    Private Sub ShowUserTable()

        Dim connection As SqlConnection = New SqlConnection("Data Source=CLARISSEALGASER\SQLEXPRESS;Initial Catalog=dbVaccineRegistry;Integrated Security=True")

        Dim showTable As New SqlCommand("SELECT * FROM [dbo].[tbl_register] ", connection)

        Dim adapter As New SqlDataAdapter(showTable)

        Dim table As New DataTable

        adapter.Fill(table)

        dgvUserTBL.DataSource = table

    End Sub

    Private Sub btnReturn_Click(sender As Object, e As EventArgs) Handles btnReturn.Click

        Me.Close()


    End Sub

End Class