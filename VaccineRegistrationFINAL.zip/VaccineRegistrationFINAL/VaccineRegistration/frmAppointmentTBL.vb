﻿Imports System.Data
Imports System.Data.SqlClient
Public Class frmAppointmentTBL

    Public Property adminLogIn As String

    Public userType As String

    Dim adminActivity As String


    Private Sub frmAppointmentsTable_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ShowAppointmentsTable()

    End Sub



    Private Sub ShowAppointmentsTable()

        Dim connection As SqlConnection = New SqlConnection("Data Source=CLARISSEALGASER\SQLEXPRESS;Initial Catalog=dbVaccineRegistry;Integrated Security=True")

        Dim showTable As New SqlCommand("SELECT * FROM [dbo].[tbl_appointment] ", connection)

        Dim adapter As New SqlDataAdapter(showTable)

        Dim table As New DataTable

        adapter.Fill(table)

        dgvAppointmentTBL.DataSource = table

    End Sub



    Private Sub btnReturn_Click(sender As Object, e As EventArgs) Handles btnReturn.Click

        Me.Close()


    End Sub



End Class