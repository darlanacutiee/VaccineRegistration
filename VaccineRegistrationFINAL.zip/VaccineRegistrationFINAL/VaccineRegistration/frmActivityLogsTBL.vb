﻿Imports System.Data
Imports System.Data.SqlClient
Public Class frmActivityLogsTBL

    Public Property adminLogIn As String

    Public userType As String

    Dim adminActivity As String



    Private Sub tmrActivityLogs_Tick(sender As Object, e As EventArgs) Handles tmrActivityLogs.Tick

        lblTime.Text = DateTime.Now

    End Sub



    Private Sub frmLogsTable_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ShowLogsTable()

    End Sub



    Private Sub ShowLogsTable()

        Dim connection As SqlConnection = New SqlConnection("Data Source=CLARISSEALGASER\SQLEXPRESS;Initial Catalog=dbVaccineRegistry;Integrated Security=True")

        Dim showTable As New SqlCommand("SELECT * FROM [dbo].[tbl_logs] ", connection)

        Dim adapter As New SqlDataAdapter(showTable)

        Dim table As New DataTable

        adapter.Fill(table)

        dgvLogsTBL.DataSource = table

    End Sub



    Private Sub btnReturnn_Click(sender As Object, e As EventArgs) Handles btnReturnn.Click
        Me.Close()
    End Sub



End Class