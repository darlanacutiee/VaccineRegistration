﻿Imports System.Data
Imports System.Data.SqlClient
Public Class frmLogin

    Dim usernameTbl, passTbl As String
    Dim typeofUser As String
    Dim timeLogIn As String


    Private Sub tmrLogin_Tick(sender As Object, e As EventArgs) Handles tmrLogIn.Tick

        If txtUsername.Text = "" Or txtPassword.Text = "" Then
            btnLogIn.Enabled = False
        Else
            btnLogIn.Enabled = True
        End If

        If chkShow.Checked = True Then
            txtPassword.PasswordChar = ""
        Else
            txtPassword.PasswordChar = "*"
        End If

    End Sub

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogIn.Click

        Dim User As frmUser
        User = New frmUser

        Dim Admin As frmAdmin
        Admin = New frmAdmin

        timeLogIn = DateTime.Now.ToString


        Dim conn As SqlConnection = New SqlConnection("Data Source=CLARISSEALGASER\SQLEXPRESS;Initial Catalog=dbVaccineRegistry;Integrated Security=True")

        Using checkUser As SqlCommand = New SqlCommand("SELECT [username] FROM [dbo].[tbl_register] WHERE [username] = '" + txtUsername.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [password] = '" + txtPassword.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS", conn)
            Using checkPass As SqlCommand = New SqlCommand("SELECT [password] FROM [dbo].[tbl_register] WHERE [username] = '" + txtUsername.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [password] = '" + txtPassword.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS", conn)

                conn.Open()

                usernameTbl = checkUser.ExecuteScalar()
                passTbl = checkPass.ExecuteScalar()

                User.userString = usernameTbl
                User.passString = passTbl



                If (txtUsername.Text = usernameTbl And txtPassword.Text = passTbl) And (txtUsername.Text <> "ADMIN" And txtPassword.Text <> "GROUP8ADMIN") Then

                    typeofUser = "User"

                    Dim conn2 As SqlConnection = New SqlConnection("Data Source=CLARISSEALGASER\SQLEXPRESS;Initial Catalog=dbVaccineRegistry;Integrated Security=True")
                    Dim updateUserLogin As SqlCommand = New SqlCommand("INSERT INTO [dbo].[tbl_logs] ([username],[type],[log_in]) VALUES('" + txtUsername.Text + "','" + typeofUser + "','" + timeLogIn + "')", conn)

                    conn2.Open()
                    updateUserLogin.ExecuteNonQuery()
                    conn2.Close()

                    Me.Hide()
                    User.Show()

                ElseIf txtUsername.Text = "ADMIN" And txtPassword.Text = "GROUP8ADMIN" Then

                    typeofUser = "System Admin"

                    Admin.userType = "ADMIN"


                    Dim conn2 As SqlConnection = New SqlConnection("Data Source=CLARISSEALGASER\SQLEXPRESS;Initial Catalog=dbVaccineRegistry;Integrated Security=True")
                    Dim updateAdminLogin As SqlCommand = New SqlCommand("INSERT INTO [dbo].[tbl_logs] ([username],[type],[log_in]) VALUES('" + txtUsername.Text + "','" + typeofUser + "','" + timeLogIn + "')", conn)

                    conn2.Open()
                    updateAdminLogin.ExecuteNonQuery()
                    conn2.Close()

                    Me.Hide()
                    Admin.Show()

                Else
                    MessageBox.Show("Invalid Username or Password.", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If

                conn.Close()



                User.userlogIn = timeLogIn
                Admin.adminLogIn = timeLogIn

            End Using
        End Using

    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        Dim Homepage As frmHome
        Homepage = New frmHome

        txtUsername.Clear()
        txtPassword.Clear()

        Me.Hide()
        Homepage.Show()

    End Sub

End Class