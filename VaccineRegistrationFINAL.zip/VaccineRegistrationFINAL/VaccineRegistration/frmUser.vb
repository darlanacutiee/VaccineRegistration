﻿Imports System.Data
Imports System.Data.SqlClient
Public Class frmUser

    Public Property userString As String
    Public Property passString As String
    Public Property userlogIn As String
    Public Property activity As String


    Dim firstDoseDateString, firstDoseVaccineString, firstDoseVenueString As Object

    Dim secondDoseDateString, secondDoseVaccineString, secondDoseVenueString As Object

    Dim nullObject As DBNull


    Private Sub frmUser_Load(ByVal sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        vaxx()
        vaxxdose()
        vaxxVenue()

    End Sub


    Private Sub btnRefreshForm_Click(ByVal sender As System.Object, e As System.EventArgs)


    End Sub


    Public Sub vaxx()

        Dim conn As SqlConnection = New SqlConnection("Data Source=CLARISSEALGASER\SQLEXPRESS;Initial Catalog=dbVaccineRegistry;Integrated Security=True")

        Using getAccountId As SqlCommand = New SqlCommand("SELECT [regis_id] FROM [dbo].[tbl_register] WHERE [username] = '" + userString + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [password] = '" + passString + "' COLLATE SQL_Latin1_General_CP1_CS_AS", conn)
            Using getTypeID As SqlCommand = New SqlCommand("SELECT [id_type] FROM [dbo].[tbl_register] WHERE [username] = '" + userString + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [password] = '" + passString + "' COLLATE SQL_Latin1_General_CP1_CS_AS", conn)
                Using getPriorityLevel As SqlCommand = New SqlCommand("SELECT [prio_level] FROM [dbo].[tbl_register] WHERE [username] = '" + userString + "'COLLATE SQL_Latin1_General_CP1_CS_AS AND [password] = '" + passString + "' COLLATE SQL_Latin1_General_CP1_CS_AS", conn)
                    Using getFirstName As SqlCommand = New SqlCommand("SELECT [first_name] FROM [dbo].[tbl_register] WHERE [username] = '" + userString + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [password] = '" + passString + "' COLLATE SQL_Latin1_General_CP1_CS_AS", conn)
                        Using getMiddleName As SqlCommand = New SqlCommand("SELECT [middle_name] FROM [dbo].[tbl_register] WHERE [username] = '" + userString + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [password] = '" + passString + "' COLLATE SQL_Latin1_General_CP1_CS_AS", conn)
                            Using getLastName As SqlCommand = New SqlCommand("SELECT [last_name] FROM [dbo].[tbl_register] WHERE [username] = '" + userString + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [password] = '" + passString + "' COLLATE SQL_Latin1_General_CP1_CS_AS", conn)
                                Using getBirthday As SqlCommand = New SqlCommand("SELECT [birthdate] FROM [dbo].[tbl_register] WHERE [username] = '" + userString + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [password] = '" + passString + "' COLLATE SQL_Latin1_General_CP1_CS_AS", conn)
                                    Using getAddress As SqlCommand = New SqlCommand("SELECT [address] FROM [dbo].[tbl_register] WHERE [username] = '" + userString + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [password] = '" + passString + "' COLLATE SQL_Latin1_General_CP1_CS_AS", conn)
                                        Using getContactNumber As SqlCommand = New SqlCommand("SELECT [contactno] FROM [dbo].[tbl_register] WHERE [username] = '" + userString + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [password] = '" + passString + "' COLLATE SQL_Latin1_General_CP1_CS_AS", conn)
                                            Using getGender As SqlCommand = New SqlCommand("SELECT [gender] FROM [dbo].[tbl_register] WHERE [username] = '" + userString + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [password] = '" + passString + "' COLLATE SQL_Latin1_General_CP1_CS_AS", conn)
                                                Using get1stDoseDate As SqlCommand = New SqlCommand("SELECT [first_dose] FROM [dbo].[tbl_register] WHERE [username] = '" + userString + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [password] = '" + passString + "' COLLATE SQL_Latin1_General_CP1_CS_AS", conn)
                                                    Using get2ndDoseDate As SqlCommand = New SqlCommand("SELECT [second_dose] FROM [dbo].[tbl_register] WHERE [username] = '" + userString + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [password] = '" + passString + "' COLLATE SQL_Latin1_General_CP1_CS_AS", conn)

                                                        conn.Open()

                                                        Try
                                                            lblUsername.Text = userString
                                                            txtRegisno.Text = getAccountId.ExecuteScalar()
                                                            lblIdtype.Text = getTypeID.ExecuteScalar()
                                                            lblPrioLevel.Text = getPriorityLevel.ExecuteScalar()
                                                            lblFirstname.Text = getFirstName.ExecuteScalar()
                                                            lblMidname.Text = getMiddleName.ExecuteScalar()
                                                            lblLastname.Text = getLastName.ExecuteScalar()
                                                            lblBirthday.Text = getBirthday.ExecuteScalar()
                                                            lblAddress.Text = getAddress.ExecuteScalar()
                                                            lblContact.Text = getContactNumber.ExecuteScalar()
                                                            lblGender.Text = getGender.ExecuteScalar()
                                                            firstDoseDateString = get1stDoseDate.ExecuteScalar()
                                                            secondDoseDateString = get2ndDoseDate.ExecuteScalar()

                                                            If firstDoseDateString IsNot Nothing Then


                                                                If firstDoseDateString.GetType.Equals(nullObject) Then
                                                                    txtFirstDoseDate.Text = ""
                                                                Else
                                                                    txtFirstDoseDate.Text = firstDoseDateString.ToString
                                                                End If

                                                                If secondDoseDateString.GetType.Equals(nullObject) Then
                                                                    txtSecondDoseDate.Text = ""
                                                                Else
                                                                    txtSecondDoseDate.Text = secondDoseDateString.ToString
                                                                End If

                                                                Dim Generate As New MessagingToolkit.Barcode.BarcodeEncoder
                                                                Generate.BackColor = Color.GhostWhite
                                                                Generate.LabelFont = New Font("Arial", 7, FontStyle.Regular)
                                                                Generate.IncludeLabel = False
                                                                Generate.CustomLabel = txtRegisno.Text

                                                                Try
                                                                    pbQR.Image = New Bitmap(Generate.Encode(MessagingToolkit.Barcode.BarcodeFormat.QRCode, txtRegisno.Text))
                                                                    pbQR.SizeMode = PictureBoxSizeMode.Zoom
                                                                Catch ex As Exception
                                                                    pbQR.Image = Nothing
                                                                End Try

                                                            Else
                                                                txtFirstDoseDate.Text = ""

                                                            End If

                                                        Catch ex As Exception
                                                            MsgBox(ex.ToString())
                                                        End Try



                                                        conn.Close()

                                                    End Using
                                                End Using
                                            End Using
                                        End Using
                                    End Using
                                End Using
                            End Using
                        End Using
                    End Using
                End Using
            End Using
        End Using


    End Sub






    Public Sub vaxxdose()

        Dim conn As SqlConnection = New SqlConnection("Data Source=CLARISSEALGASER\SQLEXPRESS;Initial Catalog=dbVaccineRegistry;Integrated Security=True")

        Using checkFirstDose As SqlCommand = New SqlCommand("SELECT [vaccine_brand] FROM [dbo].[tbl_appointment] WHERE [regis_id] = '" + txtRegisno.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [date] = '" + txtFirstDoseDate.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS", conn)
            Using checkSecondDose As SqlCommand = New SqlCommand("SELECT [vaccine_brand] FROM [dbo].[tbl_appointment] WHERE [regis_id] = '" + txtRegisno.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [date] = '" + txtSecondDoseDate.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS", conn)

                conn.Open()

                Try

                    firstDoseVaccineString = checkFirstDose.ExecuteScalar()
                    secondDoseVaccineString = checkSecondDose.ExecuteScalar()

                    If firstDoseVaccineString Is Nothing Then
                        txt1VBrand.Text = ""
                    Else
                        txt1VBrand.Text = firstDoseVaccineString.ToString
                    End If


                    If secondDoseVaccineString Is Nothing Then
                        txt2VBrand.Text = ""
                    Else
                        txt2VBrand.Text = secondDoseVaccineString.ToString
                    End If

                Catch ex As Exception
                    MsgBox(ex.ToString())
                End Try

                conn.Close()

            End Using
        End Using

    End Sub

    Public Sub vaxxVenue()

        Dim conn As SqlConnection = New SqlConnection("Data Source=CLARISSEALGASER\SQLEXPRESS;Initial Catalog=dbVaccineRegistry;Integrated Security=True")

        Using checkFirstDoseVenue As SqlCommand = New SqlCommand("SELECT [venue] FROM [dbo].[tbl_appointment] WHERE [regis_id] = '" + txtRegisno.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [date] = '" + txtFirstDoseDate.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS", conn)
            Using checkSecondDoseVenue As SqlCommand = New SqlCommand("SELECT [venue] FROM [dbo].[tbl_appointment] WHERE [regis_id] = '" + txtRegisno.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [date] = '" + txtSecondDoseDate.Text + "' COLLATE SQL_Latin1_General_CP1_CS_AS", conn)

                conn.Open()

                Try

                    firstDoseVenueString = checkFirstDoseVenue.ExecuteScalar()
                    secondDoseVenueString = checkSecondDoseVenue.ExecuteScalar()

                    If firstDoseVenueString Is Nothing Then
                        txt1Venue.Text = ""
                    Else
                        txt1Venue.Text = firstDoseVenueString.ToString
                    End If


                    If secondDoseVenueString Is Nothing Then
                        txt2Venue.Text = ""
                    Else
                        txt2Venue.Text = secondDoseVenueString.ToString
                    End If

                Catch ex As Exception
                    MsgBox(ex.ToString())
                End Try

                conn.Close()

            End Using
        End Using

    End Sub

    Private Sub tmrUser_Tick(sender As Object, e As EventArgs) Handles tmrUser.Tick

        lblTime.Text = DateTime.Now

        If txtSecondDoseDate.Text <> "" Then
            btnAppointment.Enabled = False
        End If

    End Sub

    Private Sub btnAppointment_Click(sender As Object, e As EventArgs) Handles btnAppointment.Click

        activity = "Scheduled an appointment"

        Dim Appointment As frmAppointment
        Appointment = New frmAppointment

        Dim connection2 As SqlConnection = New SqlConnection("Data Source=CLARISSEALGASER\SQLEXPRESS;Initial Catalog=dbVaccineRegistry;Integrated Security=True")
        Dim updateTimeOutLog As SqlCommand = New SqlCommand("UPDATE [dbo].[tbl_logs] SET [activity] = '" + activity + "',  [log_out] = '" + DateTime.Now.AddSeconds(103).ToString + "' WHERE [username] = '" + userString + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [log_in] = '" + userlogIn + "'", connection2)

        connection2.Open()
        updateTimeOutLog.ExecuteNonQuery()
        connection2.Close()

        Me.Close()
        Appointment.Show()



    End Sub

    Private Sub btnLogOut_Click(sender As Object, e As EventArgs) Handles btnLogOut.Click

        activity = "View Vaccine Record"

        Dim ask As DialogResult = MessageBox.Show("Are you sure you want to log-out?", "CONTINUE?", MessageBoxButtons.YesNo, MessageBoxIcon.Information)
        If ask = DialogResult.Yes Then

            Dim connection2 As SqlConnection = New SqlConnection("Data Source=CLARISSEALGASER\SQLEXPRESS;Initial Catalog=dbVaccineRegistry;Integrated Security=True")
            Dim updateTimeOutLog As SqlCommand = New SqlCommand("UPDATE [dbo].[tbl_logs] SET [activity] = '" + activity + "',  [log_out] = '" + DateTime.Now.ToString + "' WHERE [username] = '" + userString + "' COLLATE SQL_Latin1_General_CP1_CS_AS AND [log_in] = '" + userlogIn + "'", connection2)

            connection2.Open()
            updateTimeOutLog.ExecuteNonQuery()
            connection2.Close()

            Dim Homepage As frmHome
            Homepage = New frmHome

            Me.Hide()
            Homepage.Show()

        End If

    End Sub




End Class