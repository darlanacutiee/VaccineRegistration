﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmUser
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmUser))
        Me.tmrUser = New System.Windows.Forms.Timer(Me.components)
        Me.btnLogOut = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lbl12345 = New System.Windows.Forms.Label()
        Me.grpVaxxRecord = New System.Windows.Forms.GroupBox()
        Me.txtRegisno = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txt2Venue = New System.Windows.Forms.TextBox()
        Me.txt1Venue = New System.Windows.Forms.TextBox()
        Me.txt2VBrand = New System.Windows.Forms.TextBox()
        Me.txt1VBrand = New System.Windows.Forms.TextBox()
        Me.txtSecondDoseDate = New System.Windows.Forms.TextBox()
        Me.txtFirstDoseDate = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.lblContact = New System.Windows.Forms.Label()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.lblGender = New System.Windows.Forms.Label()
        Me.lblBirthday = New System.Windows.Forms.Label()
        Me.lblMidname = New System.Windows.Forms.Label()
        Me.lblFirstname = New System.Windows.Forms.Label()
        Me.lblLastname = New System.Windows.Forms.Label()
        Me.lblIdtype = New System.Windows.Forms.Label()
        Me.lblPrioLevel = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.pbQR = New System.Windows.Forms.PictureBox()
        Me.lblfd = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblsdsaa = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.btnRefresh = New System.Windows.Forms.Button()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.lblTime = New System.Windows.Forms.Label()
        Me.lblUsername = New System.Windows.Forms.Label()
        Me.btnAppointment = New System.Windows.Forms.Button()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.grpVaxxRecord.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.pbQR, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tmrUser
        '
        Me.tmrUser.Enabled = True
        Me.tmrUser.Interval = 1000
        '
        'btnLogOut
        '
        Me.btnLogOut.BackColor = System.Drawing.Color.Crimson
        Me.btnLogOut.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnLogOut.Font = New System.Drawing.Font("Microsoft Tai Le", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogOut.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnLogOut.Location = New System.Drawing.Point(1042, 24)
        Me.btnLogOut.Name = "btnLogOut"
        Me.btnLogOut.Size = New System.Drawing.Size(80, 24)
        Me.btnLogOut.TabIndex = 5
        Me.btnLogOut.Text = "Log Out"
        Me.btnLogOut.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Cascadia Code SemiLight", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(291, 190)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(0, 25)
        Me.Label1.TabIndex = 7
        '
        'lbl12345
        '
        Me.lbl12345.AutoSize = True
        Me.lbl12345.BackColor = System.Drawing.Color.GhostWhite
        Me.lbl12345.Font = New System.Drawing.Font("Cascadia Code SemiLight", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl12345.Location = New System.Drawing.Point(198, 28)
        Me.lbl12345.Name = "lbl12345"
        Me.lbl12345.Size = New System.Drawing.Size(91, 21)
        Me.lbl12345.TabIndex = 8
        Me.lbl12345.Text = "Username:"
        '
        'grpVaxxRecord
        '
        Me.grpVaxxRecord.BackColor = System.Drawing.Color.GhostWhite
        Me.grpVaxxRecord.Controls.Add(Me.txtRegisno)
        Me.grpVaxxRecord.Controls.Add(Me.Panel1)
        Me.grpVaxxRecord.Controls.Add(Me.lblContact)
        Me.grpVaxxRecord.Controls.Add(Me.lblAddress)
        Me.grpVaxxRecord.Controls.Add(Me.lblGender)
        Me.grpVaxxRecord.Controls.Add(Me.lblBirthday)
        Me.grpVaxxRecord.Controls.Add(Me.lblMidname)
        Me.grpVaxxRecord.Controls.Add(Me.lblFirstname)
        Me.grpVaxxRecord.Controls.Add(Me.lblLastname)
        Me.grpVaxxRecord.Controls.Add(Me.lblIdtype)
        Me.grpVaxxRecord.Controls.Add(Me.lblPrioLevel)
        Me.grpVaxxRecord.Controls.Add(Me.Label2)
        Me.grpVaxxRecord.Controls.Add(Me.pbQR)
        Me.grpVaxxRecord.Controls.Add(Me.lblfd)
        Me.grpVaxxRecord.Controls.Add(Me.Label6)
        Me.grpVaxxRecord.Controls.Add(Me.Label5)
        Me.grpVaxxRecord.Controls.Add(Me.lblsdsaa)
        Me.grpVaxxRecord.Controls.Add(Me.Label13)
        Me.grpVaxxRecord.Controls.Add(Me.Label12)
        Me.grpVaxxRecord.Controls.Add(Me.Label3)
        Me.grpVaxxRecord.Controls.Add(Me.Label9)
        Me.grpVaxxRecord.Controls.Add(Me.Label10)
        Me.grpVaxxRecord.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpVaxxRecord.ForeColor = System.Drawing.Color.Crimson
        Me.grpVaxxRecord.Location = New System.Drawing.Point(184, 79)
        Me.grpVaxxRecord.Name = "grpVaxxRecord"
        Me.grpVaxxRecord.Size = New System.Drawing.Size(960, 573)
        Me.grpVaxxRecord.TabIndex = 16
        Me.grpVaxxRecord.TabStop = False
        Me.grpVaxxRecord.Text = "VACCINE RECORD"
        '
        'txtRegisno
        '
        Me.txtRegisno.BackColor = System.Drawing.Color.White
        Me.txtRegisno.Enabled = False
        Me.txtRegisno.Font = New System.Drawing.Font("Lucida Sans", 12.0!)
        Me.txtRegisno.Location = New System.Drawing.Point(524, 47)
        Me.txtRegisno.Margin = New System.Windows.Forms.Padding(4)
        Me.txtRegisno.Name = "txtRegisno"
        Me.txtRegisno.Size = New System.Drawing.Size(119, 26)
        Me.txtRegisno.TabIndex = 134
        Me.txtRegisno.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Controls.Add(Me.Label18)
        Me.Panel1.Controls.Add(Me.Label17)
        Me.Panel1.Controls.Add(Me.txt2Venue)
        Me.Panel1.Controls.Add(Me.txt1Venue)
        Me.Panel1.Controls.Add(Me.txt2VBrand)
        Me.Panel1.Controls.Add(Me.txt1VBrand)
        Me.Panel1.Controls.Add(Me.txtSecondDoseDate)
        Me.Panel1.Controls.Add(Me.txtFirstDoseDate)
        Me.Panel1.Controls.Add(Me.Label19)
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Location = New System.Drawing.Point(-6, 469)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(967, 104)
        Me.Panel1.TabIndex = 144
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft New Tai Lue", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Black
        Me.Label15.Location = New System.Drawing.Point(778, 15)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(64, 21)
        Me.Label15.TabIndex = 107
        Me.Label15.Text = "VENUE"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft New Tai Lue", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Black
        Me.Label18.Location = New System.Drawing.Point(245, 15)
        Me.Label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(51, 21)
        Me.Label18.TabIndex = 1
        Me.Label18.Text = "DATE"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft New Tai Lue", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.Black
        Me.Label17.Location = New System.Drawing.Point(461, 15)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(139, 21)
        Me.Label17.TabIndex = 2
        Me.Label17.Text = "VACCINE BRAND"
        '
        'txt2Venue
        '
        Me.txt2Venue.BackColor = System.Drawing.Color.White
        Me.txt2Venue.Enabled = False
        Me.txt2Venue.Font = New System.Drawing.Font("Microsoft New Tai Lue", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt2Venue.Location = New System.Drawing.Point(679, 66)
        Me.txt2Venue.Margin = New System.Windows.Forms.Padding(4)
        Me.txt2Venue.Name = "txt2Venue"
        Me.txt2Venue.Size = New System.Drawing.Size(264, 27)
        Me.txt2Venue.TabIndex = 133
        Me.txt2Venue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt1Venue
        '
        Me.txt1Venue.BackColor = System.Drawing.Color.White
        Me.txt1Venue.Enabled = False
        Me.txt1Venue.Font = New System.Drawing.Font("Microsoft New Tai Lue", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt1Venue.Location = New System.Drawing.Point(679, 38)
        Me.txt1Venue.Margin = New System.Windows.Forms.Padding(4)
        Me.txt1Venue.Name = "txt1Venue"
        Me.txt1Venue.Size = New System.Drawing.Size(264, 27)
        Me.txt1Venue.TabIndex = 132
        Me.txt1Venue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt2VBrand
        '
        Me.txt2VBrand.BackColor = System.Drawing.Color.White
        Me.txt2VBrand.Enabled = False
        Me.txt2VBrand.Font = New System.Drawing.Font("Microsoft New Tai Lue", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt2VBrand.Location = New System.Drawing.Point(394, 66)
        Me.txt2VBrand.Margin = New System.Windows.Forms.Padding(4)
        Me.txt2VBrand.Name = "txt2VBrand"
        Me.txt2VBrand.Size = New System.Drawing.Size(280, 27)
        Me.txt2VBrand.TabIndex = 130
        Me.txt2VBrand.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txt1VBrand
        '
        Me.txt1VBrand.BackColor = System.Drawing.Color.White
        Me.txt1VBrand.Enabled = False
        Me.txt1VBrand.Font = New System.Drawing.Font("Microsoft New Tai Lue", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt1VBrand.Location = New System.Drawing.Point(394, 38)
        Me.txt1VBrand.Margin = New System.Windows.Forms.Padding(4)
        Me.txt1VBrand.Name = "txt1VBrand"
        Me.txt1VBrand.Size = New System.Drawing.Size(280, 27)
        Me.txt1VBrand.TabIndex = 129
        Me.txt1VBrand.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtSecondDoseDate
        '
        Me.txtSecondDoseDate.BackColor = System.Drawing.Color.White
        Me.txtSecondDoseDate.Enabled = False
        Me.txtSecondDoseDate.Font = New System.Drawing.Font("Microsoft New Tai Lue", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtSecondDoseDate.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.txtSecondDoseDate.Location = New System.Drawing.Point(154, 66)
        Me.txtSecondDoseDate.Margin = New System.Windows.Forms.Padding(4)
        Me.txtSecondDoseDate.Name = "txtSecondDoseDate"
        Me.txtSecondDoseDate.Size = New System.Drawing.Size(235, 27)
        Me.txtSecondDoseDate.TabIndex = 126
        Me.txtSecondDoseDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtFirstDoseDate
        '
        Me.txtFirstDoseDate.BackColor = System.Drawing.Color.White
        Me.txtFirstDoseDate.Enabled = False
        Me.txtFirstDoseDate.Font = New System.Drawing.Font("Microsoft New Tai Lue", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFirstDoseDate.Location = New System.Drawing.Point(154, 38)
        Me.txtFirstDoseDate.Margin = New System.Windows.Forms.Padding(4)
        Me.txtFirstDoseDate.Name = "txtFirstDoseDate"
        Me.txtFirstDoseDate.Size = New System.Drawing.Size(235, 27)
        Me.txtFirstDoseDate.TabIndex = 125
        Me.txtFirstDoseDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.Color.CadetBlue
        Me.Label19.Enabled = False
        Me.Label19.Font = New System.Drawing.Font("Microsoft New Tai Lue", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label19.Location = New System.Drawing.Point(26, 64)
        Me.Label19.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(126, 29)
        Me.Label19.TabIndex = 124
        Me.Label19.Text = "2ND DOSE"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.Color.CadetBlue
        Me.Label16.Enabled = False
        Me.Label16.Font = New System.Drawing.Font("Microsoft New Tai Lue", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label16.Location = New System.Drawing.Point(26, 38)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(126, 24)
        Me.Label16.TabIndex = 123
        Me.Label16.Text = "1ST DOSE"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblContact
        '
        Me.lblContact.AutoSize = True
        Me.lblContact.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblContact.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblContact.Location = New System.Drawing.Point(142, 419)
        Me.lblContact.Name = "lblContact"
        Me.lblContact.Size = New System.Drawing.Size(22, 21)
        Me.lblContact.TabIndex = 143
        Me.lblContact.Text = "--"
        Me.lblContact.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAddress.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblAddress.Location = New System.Drawing.Point(142, 374)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(22, 21)
        Me.lblAddress.TabIndex = 142
        Me.lblAddress.Text = "--"
        Me.lblAddress.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblGender
        '
        Me.lblGender.AutoSize = True
        Me.lblGender.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGender.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblGender.Location = New System.Drawing.Point(461, 99)
        Me.lblGender.Name = "lblGender"
        Me.lblGender.Size = New System.Drawing.Size(22, 21)
        Me.lblGender.TabIndex = 141
        Me.lblGender.Text = "--"
        Me.lblGender.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblBirthday
        '
        Me.lblBirthday.AutoSize = True
        Me.lblBirthday.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBirthday.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblBirthday.Location = New System.Drawing.Point(142, 336)
        Me.lblBirthday.Name = "lblBirthday"
        Me.lblBirthday.Size = New System.Drawing.Size(22, 21)
        Me.lblBirthday.TabIndex = 140
        Me.lblBirthday.Text = "--"
        Me.lblBirthday.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblMidname
        '
        Me.lblMidname.AutoSize = True
        Me.lblMidname.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMidname.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblMidname.Location = New System.Drawing.Point(142, 240)
        Me.lblMidname.Name = "lblMidname"
        Me.lblMidname.Size = New System.Drawing.Size(22, 21)
        Me.lblMidname.TabIndex = 139
        Me.lblMidname.Text = "--"
        Me.lblMidname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblFirstname
        '
        Me.lblFirstname.AutoSize = True
        Me.lblFirstname.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFirstname.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblFirstname.Location = New System.Drawing.Point(142, 202)
        Me.lblFirstname.Name = "lblFirstname"
        Me.lblFirstname.Size = New System.Drawing.Size(22, 21)
        Me.lblFirstname.TabIndex = 138
        Me.lblFirstname.Text = "--"
        Me.lblFirstname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblLastname
        '
        Me.lblLastname.AutoSize = True
        Me.lblLastname.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLastname.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblLastname.Location = New System.Drawing.Point(142, 162)
        Me.lblLastname.Name = "lblLastname"
        Me.lblLastname.Size = New System.Drawing.Size(22, 21)
        Me.lblLastname.TabIndex = 137
        Me.lblLastname.Text = "--"
        Me.lblLastname.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblIdtype
        '
        Me.lblIdtype.AutoSize = True
        Me.lblIdtype.Font = New System.Drawing.Font("Microsoft Tai Le", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblIdtype.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblIdtype.Location = New System.Drawing.Point(142, 99)
        Me.lblIdtype.Name = "lblIdtype"
        Me.lblIdtype.Size = New System.Drawing.Size(22, 21)
        Me.lblIdtype.TabIndex = 136
        Me.lblIdtype.Text = "--"
        Me.lblIdtype.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblPrioLevel
        '
        Me.lblPrioLevel.AutoSize = True
        Me.lblPrioLevel.Font = New System.Drawing.Font("Microsoft Tai Le", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPrioLevel.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblPrioLevel.Location = New System.Drawing.Point(142, 48)
        Me.lblPrioLevel.Name = "lblPrioLevel"
        Me.lblPrioLevel.Size = New System.Drawing.Size(26, 23)
        Me.lblPrioLevel.TabIndex = 135
        Me.lblPrioLevel.Text = "--"
        Me.lblPrioLevel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label2.Location = New System.Drawing.Point(386, 99)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(69, 21)
        Me.Label2.TabIndex = 33
        Me.Label2.Text = "Gender:"
        '
        'pbQR
        '
        Me.pbQR.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.pbQR.Location = New System.Drawing.Point(676, 35)
        Me.pbQR.Name = "pbQR"
        Me.pbQR.Size = New System.Drawing.Size(265, 240)
        Me.pbQR.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pbQR.TabIndex = 31
        Me.pbQR.TabStop = False
        '
        'lblfd
        '
        Me.lblfd.AutoSize = True
        Me.lblfd.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblfd.Location = New System.Drawing.Point(57, 334)
        Me.lblfd.Name = "lblfd"
        Me.lblfd.Size = New System.Drawing.Size(79, 21)
        Me.lblfd.TabIndex = 29
        Me.lblfd.Text = "Birthday:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label6.Location = New System.Drawing.Point(36, 417)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(100, 21)
        Me.Label6.TabIndex = 27
        Me.Label6.Text = "Contact No."
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label5.Location = New System.Drawing.Point(94, 99)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(35, 21)
        Me.Label5.TabIndex = 26
        Me.Label5.Text = "I.D."
        '
        'lblsdsaa
        '
        Me.lblsdsaa.AutoSize = True
        Me.lblsdsaa.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblsdsaa.Location = New System.Drawing.Point(62, 372)
        Me.lblsdsaa.Name = "lblsdsaa"
        Me.lblsdsaa.Size = New System.Drawing.Size(74, 21)
        Me.lblsdsaa.TabIndex = 22
        Me.lblsdsaa.Text = "Address:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label13.Location = New System.Drawing.Point(386, 49)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(131, 21)
        Me.Label13.TabIndex = 21
        Me.Label13.Text = "Registration no."
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label12.Location = New System.Drawing.Point(21, 50)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(115, 21)
        Me.Label12.TabIndex = 18
        Me.Label12.Text = "Priority Level:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label3.Location = New System.Drawing.Point(14, 239)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(115, 21)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Middle name:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label9.Location = New System.Drawing.Point(36, 201)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(93, 21)
        Me.Label9.TabIndex = 4
        Me.Label9.Text = "First name:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Label10.Location = New System.Drawing.Point(38, 161)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(91, 21)
        Me.Label10.TabIndex = 3
        Me.Label10.Text = "Last name:"
        '
        'btnRefresh
        '
        Me.btnRefresh.Location = New System.Drawing.Point(917, 15)
        Me.btnRefresh.Name = "btnRefresh"
        Me.btnRefresh.Size = New System.Drawing.Size(75, 23)
        Me.btnRefresh.TabIndex = 24
        Me.btnRefresh.Text = "Refresh"
        Me.btnRefresh.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Label11.Font = New System.Drawing.Font("Microsoft New Tai Lue", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.CadetBlue
        Me.Label11.Location = New System.Drawing.Point(12, 239)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(165, 17)
        Me.Label11.TabIndex = 23
        Me.Label11.Text = "BOOK AN APPOINTMENT"
        '
        'lblTime
        '
        Me.lblTime.AutoSize = True
        Me.lblTime.BackColor = System.Drawing.Color.Transparent
        Me.lblTime.Font = New System.Drawing.Font("Microsoft Tai Le", 10.0!)
        Me.lblTime.Location = New System.Drawing.Point(12, 624)
        Me.lblTime.Name = "lblTime"
        Me.lblTime.Size = New System.Drawing.Size(20, 18)
        Me.lblTime.TabIndex = 26
        Me.lblTime.Text = "--"
        '
        'lblUsername
        '
        Me.lblUsername.AutoSize = True
        Me.lblUsername.BackColor = System.Drawing.Color.GhostWhite
        Me.lblUsername.Font = New System.Drawing.Font("Cascadia Code", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUsername.ForeColor = System.Drawing.Color.CadetBlue
        Me.lblUsername.Location = New System.Drawing.Point(291, 24)
        Me.lblUsername.Name = "lblUsername"
        Me.lblUsername.Size = New System.Drawing.Size(34, 25)
        Me.lblUsername.TabIndex = 34
        Me.lblUsername.Text = "--"
        '
        'btnAppointment
        '
        Me.btnAppointment.BackColor = System.Drawing.SystemColors.ControlLight
        Me.btnAppointment.BackgroundImage = Global.VaccineRegistration.My.Resources.Resources._3
        Me.btnAppointment.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.btnAppointment.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.btnAppointment.Location = New System.Drawing.Point(35, 259)
        Me.btnAppointment.Name = "btnAppointment"
        Me.btnAppointment.Size = New System.Drawing.Size(108, 109)
        Me.btnAppointment.TabIndex = 12
        Me.btnAppointment.UseVisualStyleBackColor = False
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.SystemColors.ControlLight
        Me.PictureBox2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox2.Location = New System.Drawing.Point(2, 7)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(176, 645)
        Me.PictureBox2.TabIndex = 2
        Me.PictureBox2.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.GhostWhite
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PictureBox1.Location = New System.Drawing.Point(183, 9)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(960, 64)
        Me.PictureBox1.TabIndex = 1
        Me.PictureBox1.TabStop = False
        '
        'PictureBox4
        '
        Me.PictureBox4.BackColor = System.Drawing.SystemColors.ControlLight
        Me.PictureBox4.Image = Global.VaccineRegistration.My.Resources.Resources.G8
        Me.PictureBox4.Location = New System.Drawing.Point(35, 24)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(108, 96)
        Me.PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox4.TabIndex = 135
        Me.PictureBox4.TabStop = False
        '
        'frmUser
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Gainsboro
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1170, 664)
        Me.ControlBox = False
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.lblUsername)
        Me.Controls.Add(Me.lblTime)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.grpVaxxRecord)
        Me.Controls.Add(Me.btnAppointment)
        Me.Controls.Add(Me.lbl12345)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnLogOut)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btnRefresh)
        Me.DoubleBuffered = True
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmUser"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.grpVaxxRecord.ResumeLayout(False)
        Me.grpVaxxRecord.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.pbQR, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents tmrUser As Timer
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents btnLogOut As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents lbl12345 As Label
    Friend WithEvents btnAppointment As Button
    Friend WithEvents grpVaxxRecord As GroupBox
    Friend WithEvents Label13 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents btnRefresh As Button
    Friend WithEvents lblsdsaa As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents pbQR As PictureBox
    Friend WithEvents lblfd As Label
    Friend WithEvents lblTime As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblUsername As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents txt2Venue As TextBox
    Friend WithEvents txt1Venue As TextBox
    Friend WithEvents txt2VBrand As TextBox
    Friend WithEvents txt1VBrand As TextBox
    Friend WithEvents txtSecondDoseDate As TextBox
    Friend WithEvents txtFirstDoseDate As TextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents lblContact As Label
    Friend WithEvents lblAddress As Label
    Friend WithEvents lblGender As Label
    Friend WithEvents lblBirthday As Label
    Friend WithEvents lblMidname As Label
    Friend WithEvents lblFirstname As Label
    Friend WithEvents lblLastname As Label
    Friend WithEvents lblIdtype As Label
    Friend WithEvents lblPrioLevel As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents txtRegisno As TextBox
    Friend WithEvents PictureBox4 As PictureBox
End Class
